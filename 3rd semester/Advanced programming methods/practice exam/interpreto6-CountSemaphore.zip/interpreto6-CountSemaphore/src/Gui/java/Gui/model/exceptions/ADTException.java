package Gui.model.exceptions;

public class ADTException extends IException {
    public ADTException(String msg) {
        super(msg);
    }
}