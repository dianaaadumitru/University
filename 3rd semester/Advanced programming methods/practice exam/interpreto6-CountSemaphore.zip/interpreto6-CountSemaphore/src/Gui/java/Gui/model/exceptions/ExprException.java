package Gui.model.exceptions;

public class ExprException extends IException {
    public ExprException(String msg) {
        super(msg);
    }
}