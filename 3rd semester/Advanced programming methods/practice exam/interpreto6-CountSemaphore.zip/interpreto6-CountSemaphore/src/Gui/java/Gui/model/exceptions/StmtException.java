package Gui.model.exceptions;

public class StmtException extends IException {
    public StmtException(String msg) {
        super(msg);
    }
}